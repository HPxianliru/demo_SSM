CREATE PACKAGE BODY reportPack
As
PROCEDURE reportProc(r_CUR OUT reportCur) 


begin
Open r_Cur For
Select * From Nsp_Bc_Cooperate where Cooperatetype='03';

end Reportpack;
/
