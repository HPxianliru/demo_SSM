CREATE PACKAGE reportPack
AS 
--这个是游标
    TYPE reportCur IS REF CURSOR;
--这个是过程 
    PROCEDURE reportProc(r_CUR OUT reportCur); 

End Reportpack;
/
