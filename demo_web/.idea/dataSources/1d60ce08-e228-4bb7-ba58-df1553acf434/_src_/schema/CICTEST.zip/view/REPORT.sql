CREATE VIEW REPORT AS SELECT to_char(substr(o.areacode,0,2))||'0000' provincecode,
 c.cooperatename cooperatename, c.cooperatecode,c.cooperatetype,o.custservice custservice,
 r.sumpremium,p.transdate
FROM ge_pro_policyrelation p    
LEFT JOIN ge_pro_order o    
ON o.orderno = p.orderno       
LEFT JOIN ge_pro_risk r    
ON r.orderno   = p.orderno    
AND r.riskcode = p.productcode    
LEFT JOIN ge_bc_risk br    
ON br.riskcode = r.riskcode   
left join nsp_bc_cooperate c on o.cooperatecode = c.cooperatecode
where p.policyno is not null  
And p.transdate is not null
/
