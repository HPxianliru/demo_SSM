CREATE procedure p1( code in varchar2,  coop out varchar2 ) is
begin
 select cooperatecode into coop from nsp_bc_cooperate where servicecode = code;
 end p1;
/
