CREATE Procedure Coop_Query As 
Cooperatename Varchar2(30);


Begin 
  Select Cooperatename Into  Cooperatename  From Nsp_Bc_Cooperate Where CooperateType='03';
  Dbms_Output.Put_Line(cooperateName);
End;

Select * From Pay_Requestinfo Where Transno In ('JY10160128163438584
','JY10160128163738590
');
/
