CREATE Procedure coop_proc as 

bservicecode   Nsp_Bc_Cooperate.serviceCode%type;

Begin 
  Select Servicecode Into  Bservicecode  From Nsp_Bc_Cooperate Where Cooperatecode='W202CMCC';
  Dbms_Output.Put_Line(Bservicecode);
End;
/
