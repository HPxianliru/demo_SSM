CREATE PROCEDURE  reportProc_1( r_CUR_1 OUT reportPack.reportCur,r_CUR_2 out reportPack.reportCur )

 
as

Begin
Open R_Cur_1 For
select nn.cooperateCode ,nn.cooperateName,(

Select Wm_Concat(Riskcode || '|' ||Mmm ||'|' ||Nums) Coops
from
(
select AA.cooperateCode,aa.riskCode , sum(aa.money) mmm ,count(*)  nums from

(SELECT 
  N.Cooperatename 合作方名称,
  n.CooperateCode,
  p.policyno  保单号,
  br.riskcname 险种,
  r.sumpremium  money,
  Decode(R.Riskcode,'0332',Vt.Currenttax+Vt.Latefee+Vt.Formertax ,'') 车船税,
  R.Riskcode
 -- n.cooperateType

FROM ge_pro_policyrelation p
LEFT JOIN ge_pro_order o
ON o.orderno = p.orderno
LEFT JOIN ge_pro_vehicletax vt
ON vt.orderno = p.orderno
LEFT JOIN ge_pro_risk r
ON r.orderno   = p.orderno
AND r.riskcode = p.productcode
LEFT JOIN ge_bc_risk br
ON br.riskcode = r.riskcode
left join nsp_bc_cooperate n
on n.cooperateCode= o.cooperatecode
Where P.Flag ='1'
and n.cooperateType='01'  ---and n.webflag='0'

--And O.Inputdate <  Sysdate  And  O.Inputdate > = To_Date('2015-01-01 ','yyyy-mm-dd')              --to_date('2016-06-20 ','yyyy-mm-dd')
 ) Aa Group By Aa.Cooperatecode,Aa.Riskcode  
 Having  Aa.Riskcode In ('0335','0360','0332')
 
 )  bb
 
 Where Bb.Cooperatecode = Nn.Cooperatecode
 and nums > 0 ) coops
--Order By Aa.Riskcode
From
(
select distinct n2.cooperatecode,n2.cooperateName from ge_pro_policyrelation p2

Left Join Ge_Pro_Order O2
on p2.orderNo = o2.orderNo
Left Join Nsp_Bc_Cooperate N2
On O2.Cooperatecode = N2.Cooperatecode
Where P2.Flag='1' And N2.cooperateType='01'
order by n2.cooperateCode
) nn
--And Substr(Nn.Cooperatecode,Length(Nn.Cooperatecode)-3,4)!='8801'
;
Open R_Cur_2 For
select nn.cooperateCode ,nn.cooperateName,(

Select Wm_Concat(Riskcode || '|' ||Mmm ||'|' ||Nums) Coops
from
(
select AA.cooperateCode,aa.riskCode , sum(aa.money) mmm ,count(*)  nums from

(SELECT 
  N.Cooperatename 合作方名称,
  n.CooperateCode,
  p.policyno  保单号,
  br.riskcname 险种,
  r.sumpremium  money,
  Decode(R.Riskcode,'0332',Vt.Currenttax+Vt.Latefee+Vt.Formertax ,'') 车船税,
  R.Riskcode
 -- n.cooperateType

FROM ge_pro_policyrelation p
LEFT JOIN ge_pro_order o
ON o.orderno = p.orderno
LEFT JOIN ge_pro_vehicletax vt
ON vt.orderno = p.orderno
LEFT JOIN ge_pro_risk r
ON r.orderno   = p.orderno
AND r.riskcode = p.productcode
LEFT JOIN ge_bc_risk br
ON br.riskcode = r.riskcode
left join nsp_bc_cooperate n
on n.cooperateCode= o.cooperatecode
Where P.Flag ='1'
and n.cooperateType='01'  ---and n.webflag='0'

--And O.Inputdate <  Sysdate  And  O.Inputdate > = To_Date('2015-01-01 ','yyyy-mm-dd')              --to_date('2016-06-20 ','yyyy-mm-dd')
 ) Aa Group By Aa.Cooperatecode,Aa.Riskcode  
 Having  Aa.Riskcode In ('0335','0360','0332')
 
 )  bb
 
 Where Bb.Cooperatecode = Nn.Cooperatecode
 and nums > 0 ) coops
--Order By Aa.Riskcode
From
(
select distinct n2.cooperatecode,n2.cooperateName from ge_pro_policyrelation p2

Left Join Ge_Pro_Order O2
on p2.orderNo = o2.orderNo
Left Join Nsp_Bc_Cooperate N2
On O2.Cooperatecode = N2.Cooperatecode
Where P2.Flag='1' And N2.cooperateType='01'
order by n2.cooperateCode
) nn
--And Substr(Nn.Cooperatecode,Length(Nn.Cooperatecode)-3,4)!='8801'
;

end reportProc_1;
/
