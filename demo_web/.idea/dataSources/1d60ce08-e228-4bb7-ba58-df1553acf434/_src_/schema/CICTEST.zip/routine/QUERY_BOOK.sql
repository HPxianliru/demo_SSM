CREATE procedure query_book
 select *from nsp_bc_cooperate;


/
