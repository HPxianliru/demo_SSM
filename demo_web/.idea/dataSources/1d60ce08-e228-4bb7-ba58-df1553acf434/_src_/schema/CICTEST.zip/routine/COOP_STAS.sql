CREATE Procedure Coop_Stas As 
Bcoopcode Varchar2(20) ;
Begin 
cursor cursor_test is 

select nn.cooperateCode ,(

Select Wm_Concat(Riskcode || '|' ||Mmm ||'|' ||Nums) Coops
from
(
select AA.cooperateCode,aa.riskCode , sum(aa.money) mmm ,count(*)  nums from

(SELECT 
  N.Cooperatename 合作方名称,
  n.CooperateCode,
  p.policyno  保单号,
  br.riskcname 险种,
  r.sumpremium  money,
  Decode(R.Riskcode,'0332',Vt.Currenttax+Vt.Latefee+Vt.Formertax ,'') 车船税,
  R.Riskcode,
  n.cooperateType,
  to_char(r.startdate,'yyyy-mm-dd hh24:mi:ss') 起保日期,
  to_char(r.enddate,'yyyy-mm-dd hh24:mi:ss') 终保日期,
 ---o.custservice,
  to_char(o.inputdate,'yyyy-mm-dd hh24:mi:ss') 投保日期

FROM ge_pro_policyrelation p
LEFT JOIN ge_pro_order o
ON o.orderno = p.orderno
LEFT JOIN ge_pro_vehicletax vt
ON vt.orderno = p.orderno
LEFT JOIN ge_pro_risk r
ON r.orderno   = p.orderno
AND r.riskcode = p.productcode
LEFT JOIN ge_bc_risk br
ON br.riskcode = r.riskcode
left join nsp_bc_cooperate n
on n.cooperateCode= o.cooperatecode
Where P.Flag ='1'
and n.cooperateType='01'  ---and n.webflag='0'

--And O.Inputdate <  Sysdate  And  O.Inputdate > = To_Date('2015-01-01 ','yyyy-mm-dd')              --to_date('2016-06-20 ','yyyy-mm-dd')
 ) Aa Group By Aa.Cooperatecode,Aa.Riskcode  
 Having  Aa.Riskcode In ('0335','0360','0332')
 
 )  bb
 
 Where Bb.Cooperatecode = Nn.Cooperatecode
 ) coops
--Order By Aa.Riskcode
From
(
select distinct n2.cooperatecode from ge_pro_policyrelation p2

Left Join Ge_Pro_Order O2
on p2.orderNo = o2.orderNo
Left Join Nsp_Bc_Cooperate N2
On O2.Cooperatecode = N2.Cooperatecode
Where P2.Flag='1'
And N2.Cooperatetype='01'
And Substr(N2.Cooperatecode,Length(N2.Cooperatecode)-3,4)!='8801'
Order By N2.Cooperatecode

) nn
--And Substr(Nn.Cooperatecode,Length(Nn.Cooperatecode)-3,4)!='8801'
;

Row_Test Bb%Rowtype;
Begin 
For Row_Test In Cursor_Test Loop
Dbms_Output.Put_Line(Row_Test.Cooperatecode||Row_Test.Coops);
End Loop;
end;
/
