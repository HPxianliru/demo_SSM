CREATE TRIGGER MLJTEST
AFTER INSERT
  ON GE_PAY_INF
FOR EACH ROW
  declare
  paylno ge_pay_inf.paylno%type;
  paymentType  ge_pay_inf.paymenttype%type;
  flag  ge_pay_inf.flag%type;
BEGIN
  paylno := :new.paylno;
  paymentType := :new.PAYMENTTYPE;
  flag := :new.flag;
  INSERT INTO ge_bc_test VALUES(paylno,paymentType,flag,paylno);
END;
/
