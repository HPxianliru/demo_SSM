CREATE TRIGGER NSP_BC_COOPERATE_COPY
AFTER INSERT
  ON NSP_BC_COOPERATE
  declare
  myid ge_cooperate_province.id%type;
  cooperatecode ge_cooperate_province.cooperatecode%type;
  provincecode ge_cooperate_province.provincecode%type;
  citycode ge_cooperate_province.citycode%type;
  district ge_cooperate_province.district%type;
  comcode ge_cooperate_province.comcode%type;
  flag ge_cooperate_province.flag%type;
BEGIN
  --INSERT INTO ge_cooperate_province values(myid,provincecode,cooperatecode,citycode,district,comcode,flag);
  INSERT INTO ge_cooperate_province values(myid,'','','','','','');
END NSP_BC_COOPERATE_COPY;
/
